let data = [
  {
    id: 0,
    name: "제은이 동물병원",
    adrees: "대전광역시 서구 대덕대로 182",
    time: "09:00 ~ 20:00",
    good: 0,
    image:
      "https://www.dailyvet.co.kr/wp-content/uploads/2022/04/20220405eyedeal1.jpg",
    comment: ["좋네요"],
  },
  {
    id: 1,
    name: "상범이 동물병원",
    adrees: "대전광역시 서구 대덕대로 182",
    time: "09:00 ~ 20:00",
    good: 0,
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3wh43n8sMSoHNgO38VAVWLq8aWY2oaslyymD1evH8lj-N1fe5PtePI7Pj-PSCZFuWM8U&usqp=CAU",
    comment: ["좋네요", "친절해요", "착해요"],
  },
  {
    id: 2,
    name: "채림이 동물병원",
    adrees: "대전광역시 서구 대덕대로 182",
    time: "09:00 ~ 20:00",
    good: 0,
    image: "https://cdn.imweb.me/thumbnail/20201130/a6fb3d3decdb6.png",
    comment: ["좋네요", "친절해요", "착해요"],
  },
  {
    id: 3,
    name: "현진이 동물병원",
    adrees: "대전광역시 서구 대덕대로 182",
    time: "09:00 ~ 20:00",
    good: 0,
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyX0Kt8npymHv-6ddIAQ3efpQHe6it0gbFtQaqWmKeSca5FEyVem3yk7mAl22d4sFRF00&usqp=CAU",
    comment: ["좋네요", "친절해요", "착해요"],
  },
  {
    id: 4,
    name: "제은이 동물병원",
    adrees: "대전광역시 서구 대덕대로 182",
    time: "09:00 ~ 20:00",
    good: 0,
    image: "https://t1.daumcdn.net/cfile/blog/212ABC4B5497A04B2C",
    comment: ["좋네요", "친절해요"],
  },
];

export default data;
