let data = [
  { image: require("../assets/user1.png"), user: "안보현", age: 20 },
  { image: require("../assets/user1.png"), user: "안보현", age: 20 },
  { image: require("../assets/user1.png"), user: "안보현", age: 20 },
  { image: require("../assets/user1.png"), user: "안보현", age: 20 },
  { image: require("../assets/user1.png"), user: "안보현", age: 20 },
];

export default data;
