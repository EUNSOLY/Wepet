let commentData = [
  {
    userName: "이름",
    commentTime: "2023-06-01",
    image:
      "https://i.namu.wiki/i/slmFMXb1Fchs2zN0ZGOzqfuPDvhRS-H9eBp7Gp613-DNKi6i6Ct7eFkTUpauqv5HAYR97mrNqrvvcCDEyBdL_g.webp",
    comment: "잘보고갑니다용~~~",
  },
  {
    userName: "이름",
    commentTime: "2023-06-01",
    image:
      "https://i.namu.wiki/i/slmFMXb1Fchs2zN0ZGOzqfuPDvhRS-H9eBp7Gp613-DNKi6i6Ct7eFkTUpauqv5HAYR97mrNqrvvcCDEyBdL_g.webp",
    comment: "잘보고갑니다용~~~",
  },
  {
    userName: "이름",
    commentTime: "2023-06-01",
    image:
      "https://i.namu.wiki/i/slmFMXb1Fchs2zN0ZGOzqfuPDvhRS-H9eBp7Gp613-DNKi6i6Ct7eFkTUpauqv5HAYR97mrNqrvvcCDEyBdL_g.webp",
    comment: "잘보고갑니다용~~~",
  },
  {
    userName: "이름",
    commentTime: "2023-06-01",
    image:
      "https://i.namu.wiki/i/slmFMXb1Fchs2zN0ZGOzqfuPDvhRS-H9eBp7Gp613-DNKi6i6Ct7eFkTUpauqv5HAYR97mrNqrvvcCDEyBdL_g.webp",
    comment: "잘보고갑니다용~~~",
  },
  {
    userName: "이름",
    commentTime: "2023-06-01",
    image:
      "https://i.namu.wiki/i/slmFMXb1Fchs2zN0ZGOzqfuPDvhRS-H9eBp7Gp613-DNKi6i6Ct7eFkTUpauqv5HAYR97mrNqrvvcCDEyBdL_g.webp",
    comment: "잘보고갑니다용~~~",
  },
  {
    userName: "이름",
    commentTime: "2023-06-01",
    image:
      "https://i.namu.wiki/i/slmFMXb1Fchs2zN0ZGOzqfuPDvhRS-H9eBp7Gp613-DNKi6i6Ct7eFkTUpauqv5HAYR97mrNqrvvcCDEyBdL_g.webp",
    comment: "잘보고갑니다용~~~",
  },
];
