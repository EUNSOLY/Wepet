import { StyleSheet, Text, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { NativeBaseProvider, extendTheme } from "native-base";
import * as Font from "expo-font";
const config = {
  useSystemColorMode: false,
  initialColorMode: "dark",
};

export const theme = extendTheme({ config });

import LoadingPage from "./pages/LoadingPage";
import { useState, useEffect } from "react";
import StackNavigator from "./navigation/StackNavigation";

export default function App() {
  const [ready, setReady] = useState(true);
  const loadFont = () => {
    setTimeout(async () => {
      await Font.loadAsync({
        "Crown-B": require("./assets/font/Crown.ttf"),
        ...Ionicons.font,
      });
      setReady(false);
    }, 1000);
  };
  useEffect(() => {
    loadFont();
  }, []);
  return ready ? (
    <NativeBaseProvider>
      <LoadingPage />
    </NativeBaseProvider>
  ) : (
    <NativeBaseProvider>
      <NavigationContainer>
        <StackNavigator />
      </NavigationContainer>
    </NativeBaseProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
