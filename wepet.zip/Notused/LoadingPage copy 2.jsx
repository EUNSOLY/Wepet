import React from "react";
import {
  VStack,
  HStack,
  Button,
  IconButton,
  Icon,
  Text,
  NativeBaseProvider,
  Center,
  Box,
  StatusBar,
} from "native-base";
export default function LoadingPage() {
  return (
    <Center>
      <Text>로딩입니다.</Text>
    </Center>
  );
}
