import { Text, View, Image, StyleSheet, TouchableOpacity } from "react-native";

export default function Card({ content, i, navigation, route }) {
  return (
    <TouchableOpacity
      style={[styles.card, i % 2 == 0 ? styles.cardEven : null]}
      onPress={() => navigation.navigate("DetailPage", content)}
    >
      <Image style={styles.cardImg} source={{ uri: content.image }} />
      <View style={styles.cardText}>
        <Text style={styles.cardTitle} numberOfLines={1}>
          {content.title}
        </Text>
        <Text style={styles.cardDesc} numberOfLines={3}>
          {content.desc}
        </Text>
        <Text style={styles.cardDate}>{content.date}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    paddingLeft: 16,
    paddingRight: 16,
    paddingBottom: 8,
    paddingTop: 8,
    borderBottomWidth: 1,
    borderStyle: "dotted",
    borderColor: "#ddd",
  },
  cardImg: {
    width: 100,
    height: 100,
    borderRadius: 8,
    objectFit: "cover",
  },
  cardText: {
    flex: 1,
    paddingLeft: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#777",
  },
  cardDesc: {
    fontSize: 12,
  },
  cardDate: {
    fontSize: 10,
    color: "#999",
  },
  cardEven: {
    backgroundColor: "#eaeaea50",
  },
});
