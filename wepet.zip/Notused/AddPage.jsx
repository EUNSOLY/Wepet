import { StyleSheet, View, ScrollView, Alert, Platform } from "react-native";
import {
  Center,
  Pressable,
  Text,
  Input,
  TextArea,
  Button,
  Box,
  Image,
} from "native-base";
import HeaderComponent from "../components/HeaderComponent";
import ImageBlurLoading from "react-native-image-blur-loading";
import { useState, useEffect } from "react";

const bg2 = require("../assets/bg.jpg");

import { auth, db, storage } from "../config/firebase";
import { setDoc, doc, getDoc } from "firebase/firestore";
import { ref, getDownloadURL, uploadBytes } from "firebase/storage";

import loading from "../assets/loadding.gif";

// 등록을 위한 임시 이미지
const tempImage =
  "https://firebasestorage.googleapis.com/v0/b/myapp-3d2a0.appspot.com/o/food.png?alt=media&token=2602f9a5-dad2-4159-9172-b1fdef83093b";

// 이미지 피커 라이브러리
import * as ImagePicker from "expo-image-picker";

export default function AddPage({ navigation }) {
  // 게시글 등록 상태 관리
  const [image, setImage] = useState(tempImage); // 게시글 이미지
  const [imageUri, setImageUri] = useState(""); // 미리보기 이미지
  const [title, setTitle] = useState(""); // 게시글 제목
  const [titleError, setTitleError] = useState(""); // 게시글 제목 에러
  const [content, setContent] = useState(""); // 게시글 내용
  const [contentError, setContentError] = useState(""); // 게시글 내용 에러
  // 로딩 상태관리
  const [process, setProcess] = useState(false);

  const upload = async () => {
    let date = new Date(); // 현재 시간 저장
    if (title.trim() === "") {
      setTitleError("제목을 입력해주세요.");
      return false;
    } else {
      setTitleError("");
    }
    if (content.trim() === "") {
      setContentError("내용을 입력해주세요.");
      return false;
    } else {
      setContentError("");
    }
    console.log("업로드 준비중");
    setProcess(true);
    // console.log("제목", title);
    // console.log("내용", content);
    // console.log("유저", user);
    // console.log("입력시간", date);

    let data = {
      // 게시글 데이터
      title: title,
      author: user.email,
      desc: content,
      date: date.getTime(),
      uid: user.uid,
      image: image,
    };

    // 이미지 업로드 함수 실행
    const response = await fetch(imageUri);
    const blob = await response.blob();
    const imageUrl = await imageUpload(blob, data.date);
    data.image = imageUrl;
    console.log("업로드 데이터자료 --", data);

    let result = addDiary(data);
    if (result) {
      // Alert.alert("게시글 등록 완료");
      console.log("게시글 등록 완료");
      setProcess(false);
      setImageUri("");
      setTitle("");
      setContent("");
      setImage(tempImage);
      navigation.navigate("MyPage");
    }
  };

  async function imageUpload(blob, date) {
    const storageRef = ref(storage, "diary/" + date);
    const snapshot = await uploadBytes(storageRef, blob);
    const imageUrl = await getDownloadURL(snapshot.ref);
    blob.close();
    return imageUrl;
  }

  // user 정보와 storage에 등록된 이미지를 함께 등록하는 함수
  async function addDiary(content) {
    console.log("현재 유저 정보", content.uid);
    try {
      const userRef = doc(db, "users", content.uid);
      const userDoc = await getDoc(userRef);
      if (userDoc.exists()) {
        //해당 사용자 문서가 존재하면
        const userData = userDoc.data();
        console.log("입력될 닉네임 ", userData.nickName);
        content.author = userData.nickName;
        await setDoc(doc(db, "diary", `${content.date}D`), content);
        return true;
      } else {
        console.log("해당 사용자 문서가 존재하지 않습니다.");
        return false;
      }
    } catch (e) {
      console.log(err.message);
      alert("글 작성에 문제가 있습니다!", err.message);
      return false;
    }
  }

  // 이미지피커 함수
  useEffect(() => {
    getPermission();
  }, []);
  const getPermission = async () => {
    if (Platform.OS !== "web") {
      const { status } =
        await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        alert("카메라 권한을 허용해주세요.");
      }
    }
  };
  const pickImage = async () => {
    console.log("이미지 선택 함수 실행");
    try {
      let results = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        allowsEditing: true,
        aspect: [16, 9], //이미지 비율
        quality: 1, //이미지 퀄리티
      });
      // console.log(results.assets[0]?.uri); // 선택한 이미지 경로
      // setImageUri(imageData.assets[0].uri); // 미리보기 이미지 경로

      if (!results.canceled && results !== null) {
        // 이미지 선택 취소가 아닐경우
        const imageData = results.assets[0];
        // setImage(imageData.uri);
        getImageUri(imageData);
      } else {
        setImage(tempImage);
        setImageUri("");
      }
    } catch (e) {
      console.log(e);
    }
  };

  const getImageUri = async (imageData) => {
    setImageUri(imageData.uri);
  };

  // 현재 유저 정보 가져오기
  const user = auth.currentUser;
  if (user) {
    console.log("현재유저 ---", user.uid);
  } else {
    console.log("유저없음");
  }

  return (
    <ScrollView>
      {process ? (
        <Image source={loading} alt="process" style={styles.process} />
      ) : null}
      <HeaderComponent />
      <Center p={4}>
        <ImageBlurLoading
          withIndicator
          source={bg2}
          thumbnailSource={bg2}
          style={{ width: "100%", height: 80, borderRadius: 10 }}
        />
        {imageUri === "" ? (
          <Pressable
            onPress={pickImage}
            borderWidth={2}
            borderColor={"#999"}
            borderStyle={"dotted"}
            w={"100%"}
            h={150}
            borderRadius={10}
            mt={4}
            mb={4}
            justifyContent={"center"}
          >
            <Text fontSize={50} textAlign={"center"}>
              +
            </Text>
          </Pressable>
        ) : (
          <Box
            w={"100%"}
            h={150}
            borderRadius={10}
            mt={4}
            mb={4}
            borderWidth={2}
            borderColor={"#999"}
            borderStyle={"dotted"}
            overflow="hidden"
          >
            <ImageBlurLoading
              withIndicator
              thumbnailSource={{ uri: imageUri }}
              source={{ uri: imageUri }}
              style={{
                width: "100%",
                height: "100%",
              }}
            />
          </Box>
        )}

        <Input
          placeholder="제목을 입력해세요"
          fontSize={14}
          borderRadius={10}
          mb={4}
          onChangeText={(text) => setTitle(text)}
          value={title}
        />
        <Text>{titleError}</Text>
        <TextArea
          borderRadius={10}
          h={150}
          placeholder="내용을 입력해세요"
          onChangeText={(text) => setContent(text)}
          value={content}
        />
        <Text>{contentError}</Text>
        <Button onPress={upload} w={"100%"} mt={4}>
          <Text>등록</Text>
        </Button>
      </Center>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  process: {
    position: "absolute",
    top: "35%",
    left: "35%",
    width: 150,
    height: 150,
    zIndex: 100,
  },
});
